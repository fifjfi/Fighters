from random import randint

rounds = 1
random_number = 0

class Fighter():
    hp_min = 0
    hp_max = 100

class Fighter_first(Fighter):
    power_first = randint(1, 20)

class Fighter_second(Fighter):
    power_second = randint(1, 20)

fighter_first = Fighter_first()
fighter_second = Fighter_second()

print('В начале: \n\tКоличество жизней первого бойца: ' + str(Fighter.hp_max) + '\n\tКоличество жизней второго бойца: ' + str(Fighter.hp_max))

while True:

    random_action = randint(0, 1)
    random_number = randint(1, 20)

    print()
    print(rounds, 'раунд:')
    print('\n\tКоличество жизней первого бойца:',  fighter_first.hp_max, '\n\tКоличество жизней второго бойца:', fighter_second.hp_max)
    print()

    print('Первый боец наносит удар с силой:', fighter_first.power_first + random_number)
    if random_action == 1:
        fighter_second.hp_max -= fighter_first.power_first
        if fighter_second.hp_max <= 0:
            fighter_second.hp_max = 0
        print('\tКоличество жизней второго бойца:', fighter_second.hp_max)
    else:
        print()
        print('\tПромах')
        print()
        print('\tКоличество жизней второго бойца:', fighter_second.hp_max)

    print()
    print()
    print('Второй боец наносит удар с силой', fighter_second.power_second + random_number)
    if random_action == 1:
        fighter_first.hp_max -= fighter_second.power_second
        if fighter_first.hp_max < 0:
            fighter_first.hp_max = 0
        print('\tКоличество жизней первого бойца:', fighter_first.hp_max)
    else:
        print()
        print('\tПромах')
        print()
        print('\tКоличество жизней первого бойца:', fighter_first.hp_max)

    rounds += 1

    if fighter_first.hp_max <= fighter_first.hp_min or fighter_second.hp_max <= fighter_second.hp_min:
        if fighter_first.hp_max <= fighter_first.hp_min:
            print('\nПобедил ВТОРОЙ боец')
            break
        else:
            print('\nПобедил ПЕРВЫЙ боец')
            break